﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generic.Models
{
    class Student : IComparable
    {
        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }
    }
}
