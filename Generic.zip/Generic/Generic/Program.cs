﻿using Generic.Models;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Generic
            //MyList myList = new MyList();
            //myList.Add(5);
            //myList.Add(6);
            //myList.Add("lorem");
            //myList.Add(true);
            //myList.Add(new Student());

            //MyList<int> myList = new MyList<int>();
            //myList.Add(5);
            //myList.Add(6);

            //MyList<string> myListStr = new MyList<string>();
            //myListStr.Add("LOREM");

            //MyList<Student> myListStu = new MyList<Student>();


            //MyListStr myListStr = new MyListStr();
            //myListStr.Add("lorem");
            //myListStr.Add("Test");

            //MyListStudent myListStu = new MyListStudent();
            //myListStu.Add(new Student());
            #endregion

            #region Non-generic
            ArrayList arrayList = new ArrayList();
            arrayList.Add("lorem");
            arrayList.Add(5);
            arrayList.Add(5);
            arrayList.Add(true);
            //arrayList.Remove(5);
            //arrayList.RemoveAt(0);
            //Console.WriteLine(arrayList.LastIndexOf(5));
            foreach (var item in arrayList)
            {
                //Console.WriteLine(item);
            }

            //List<int> myList = new List<int>();
            ////myList.Add(true);
            //myList.Add(5);
            //myList.Add(6);

            ////myList.Remove(5);
            ////myList.RemoveAll(x=>x.);
            ////myList.Find();
            //myList.RemoveAt(0);
            //foreach (var item in myList)
            //{
            //    Console.WriteLine(item);
            //}
            LinkedList<int> linkedList = new LinkedList<int>();
            #endregion


        }
    }
    #region Generic
    class MyList<T>
        //where T:class
        //where T:struct
        //where T:new()
        //where T:IComparable
        where T:class,IComparable,new ()
    {
        private T[] arr;
        public MyList()
        {
            arr = new T[0];
        }

        public void Add(T element)
        {
            Array.Resize(ref arr, arr.Length + 1);
            arr[arr.Length - 1] = element;
        }
    }
    //class MyListStr
    //{
    //    private string[] arr;
    //    public MyListStr()
    //    {
    //        arr = new string[0];
    //    }

    //    public void Add(string element)
    //    {
    //        Array.Resize(ref arr, arr.Length + 1);
    //        arr[arr.Length - 1] = element;
    //    }
    //}
    //class MyListStudent
    //{
    //    private Student[] arr;
    //    public MyListStudent()
    //    {
    //        arr = new Student[0];
    //    }

    //    public void Add(Student element)
    //    {
    //        Array.Resize(ref arr, arr.Length + 1);
    //        arr[arr.Length - 1] = element;
    //    }
    //}
    #endregion
}
